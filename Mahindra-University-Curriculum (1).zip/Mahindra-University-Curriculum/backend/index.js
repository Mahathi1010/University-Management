// index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// case 1
// Connect to MongoDB
mongoose.connect("mongodb+srv://sushanth123:sushanth123@sumanth1.apxwy1f.mongodb.net/curriculum", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define the course schema
const courseSchema = new mongoose.Schema({
  serial_number: Number,
  name: String,
  credits: Number,
  school: String,
  branch: String,
  year: Number,
  semester: Number,
});

const Course = mongoose.model('Course', courseSchema);

// Insert sample data into the courses collection
// const sampleData = [
//   { 
//     serial_number: 1, 
//     name: "Calculus & ODE", 
//     credits: 5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   }, 
//   { 
//     serial_number: 2, 
//     name: "Chemistry I", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   }, 
//   { 
//     serial_number: 3, 
//     name: "Introduction to Electrical Engineering", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 4, 
//     name: "Electronics", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 5, 
//     name: "Engg. Drawing", 
//     credits: 1.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 6, 
//     name: "Mechanics", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 7, 
//     name: "Media Project", 
//     credits: 1.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 8, 
//     name: "English", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 8, 
//     name: "Introduction to Entrepreneurship", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 9, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 1 
//   },
//   { 
//     serial_number: 1, 
//     name: "Linear Algebra and Complex Analysis", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 2, 
//     name: "Physics I", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 3, 
//     name: "Bioinformatics", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 4, 
//     name: "Introduction to Computing", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 5, 
//     name: "Workshop Practice", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 6, 
//     name: "Earth and Environmental Science", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 7, 
//     name: "Discrete Mathematics Structures", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 8, 
//     name: "Entrepreneurship Practice", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 9, 
//     name: "Professional Ethics", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 10, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 1, 
//     semester: 2 
//   },
//   { 
//     serial_number: 1, 
//     name: "Probability and Statistics", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 2, 
//     name: "Physics II", 
//     credits: 5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 3, 
//     name: "Data Structures", 
//     credits: 5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 4, 
//     name: "Optimization Techniques for AI", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 5, 
//     name: "Signals and Systems", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 6, 
//     name: "Prog WS", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 7, 
//     name: "Lean StartUp", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 7, 
//     name: "Economics", 
//     credits: 1.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 8, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 3 
//   },
//   { 
//     serial_number: 1, 
//     name: "Numerical Methods", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 2, 
//     name: "DLD & CA", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 3, 
//     name: "Artificial and Computational Intelligence", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 4, 
//     name: "TC", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 5, 
//     name: "Machine Learning", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 6, 
//     name: "Prog WS", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 7, 
//     name: "Deep Thinking", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 8, 
//     name: "Financial Accounting", 
//     credits: 1.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 9, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 2, 
//     semester: 4 
//   },
//   { 
//     serial_number: 1, 
//     name: "DAA", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 2, 
//     name: "OOP", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5
//   },
//   { 
//     serial_number: 3, 
//     name: "OS", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 4, 
//     name: "DBMS", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 5, 
//     name: "Microprocessors and Interfacing", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 6, 
//     name: "Microprocessors and Interfacing", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 7, 
//     name: "Prog WS", 
//     credits: 1, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 8, 
//     name: "HSS/Mgmt Elective I", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 9, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 5 
//   },
//   { 
//     serial_number: 1, 
//     name: "3rd Year Project", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 2, 
//     name: "Big Data", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 3, 
//     name: "Computer Networks", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 4, 
//     name: "HPC", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 5, 
//     name: "Software Engineering", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 6, 
//     name: "One of 3 AI Alternatives", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 7, 
//     name: "Open Elective I", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 8, 
//     name: "Intro. to Prof. Develop & Employability Skills", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 9, 
//     name: "HSS/Mgmt Elective II", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 10, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 3, 
//     semester: 6 
//   },
//   { 
//     serial_number: 1, 
//     name: "Final Year Project", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7 
//   },
//   { 
//     serial_number: 2, 
//     name: "Compiler Design", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7 
//   },
//   { 
//     serial_number: 3, 
//     name: "Distributed Systems", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7 
//   },
//   { 
//     serial_number: 4, 
//     name: "Cryptography and network security", 
//     credits: 4, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 5, 
//     name: "Open elective II", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 6, 
//     name: "Open elective III", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 7, 
//     name: "Open elective III", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 8, 
//     name: "HSS/Mgmt Elective III", 
//     credits: 2, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 9, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 7
//   },
//   { 
//     serial_number: 1, 
//     name: "Final Year Project", 
//     credits: 10, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 8
//   },
//   { 
//     serial_number: 2, 
//     name: "Open elective IV", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 8
//   },
//   { 
//     serial_number: 3, 
//     name: "Open elective V", 
//     credits: 3, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 8
//   },
//   { 
//     serial_number: 4, 
//     name: "French", 
//     credits: 0.5, 
//     school: "School of Engineering", 
//     branch: "CSE", 
//     year: 4, 
//     semester: 8
//   }
// ];

// Course.insertMany(sampleData)
//   .then(() => console.log('Sample data inserted'))
//   .catch(err => console.error(err));

// API endpoints
// app.get('/api/courses', async (req, res) => {
//     const { school, branch, year, semester } = req.query;
//     console.log('Query parameters:', { school, branch, year, semester }); // Log the received query parameters
  
//     try {
//       const courses = await Course.find({ school, branch, year, semester });
//       console.log('Courses found:', courses); // Log the courses found
  
//       res.json(courses);
//     } catch (err) {
//       console.error(err);
//       res.status(500).json({ error: err.message });
//     }
//   });

// ... (existing code)

// app.get('/api/courses', async (req, res) => {
//     const { branch, year, semester } = req.query;
//     console.log('Query parameters:', { branch, year, semester });
//     try {
//       const courses = await Course.find({ branch, year, semester });
//       console.log('Courses found:', courses);
//       res.json(courses);
//     } catch (err) {
//       console.error(err);
//       res.status(500).json({ error: err.message });
//     }
//   });
  
//   // ... (existing code)

app.get('/api/courses', async (req, res) => {
    const { school, branch, year, semester } = req.query;
    console.log('Query parameters:', { school, branch, year, semester });
    try {
      const courses = await Course.find({ school, branch, year, semester });
      console.log('Courses found:', courses);
      res.json(courses);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  const port = process.env.port || 9000;
app.listen(port, () => {
  console.log('Server started on port '+port);
});
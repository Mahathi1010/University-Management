import React from 'react';
import './App.css';
import { useRef } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, NavLink, Routes } from 'react-router-dom';
import { Button } from './components/ui/button';
import SchoolOfEngineering from './components/SchoolOfEngineering';
import SchoolOfLaw from './components/SchoolOfLaw';
import SchoolOfManagement from './components/SchoolOfManagement';
import SchoolOfEducation from './components/SchoolOfEducation';
import GetCoursesEngg from './components/SchoolOfEngineering/GetCoursesEngg';
import GetScheduleEngg from './components/SchoolOfEngineering/GetScheduleEngg';
import { useState } from 'react';
// import { Transition } from "@headlessui/react";
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import styled from 'styled-components';
import GetCoursesLaw from './components/SchoolOfLaw/GetCoursesLaw';
import GetScheduleLaw from './components/SchoolOfLaw/GetScheduleLaw';
import GetCoursesMngt from './components/SchoolOfManagement/GetCoursesMngt';
import GetScheduleMngt from './components/SchoolOfManagement/GetScheduleMngt';
import GetCoursesEdu from './components/SchoolOfEducation/GetCoursesEdu';
import GetScheduleEdu from './components/SchoolOfEducation/GetScheduleEdu';

// Header component
const Header = ({ handleScrollToCourse,handleScrollToCampus,handleScrollToFacilities }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const handleLinkClick = () => {
    setMenuOpen(false); // Close the hamburger menu
  };

  // const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="header">
      <nav>
        <a href="index.html">
            <div className='logo-image'>
              <img src="./image/logo.png" id="logo-img" alt="Logo" />
            </div>
        </a>
        <div className="menu" onClick={() => setMenuOpen(!menuOpen)}>
          <span></span>
          <span></span>
          <span></span>
          {/* <span></span> */}
        </div>
        <div className="nav-links" id="navLinks">
            <ul className={menuOpen ? "open" : ""}>
              <li>
                <Link to="/" onClick={handleLinkClick}>Home</Link>
              </li>
              <li>
                <Link onClick={() => { handleScrollToCourse(); handleLinkClick(); }}>Courses</Link>
              </li>
              <li>
                <Link onClick={() => { handleScrollToCourse(); handleLinkClick(); }}>Timetable</Link>
              </li>
              <li>
                <Link onClick={() => { handleScrollToCourse(); handleLinkClick(); }}>Schedule</Link>
              </li>
              <li>
                <Link onClick={() => { handleScrollToCampus(); handleLinkClick(); }}>Campus</Link>
              </li>
              {/* <li>
                <Link onClick={handleScrollToFacilities}>Facilities</Link>
              </li> */}
              <li>
                <Link onClick={() => { handleScrollToFacilities(); handleLinkClick(); }}>Facilities</Link>
              </li>
            </ul>
          </div>
      </nav>
      
      <div className="text-box">
        <h1>Mahindra University</h1>
        <p>
          École Centrale School of Engineering, Mahindra University (MU) Hyderabad, offers several four-year B.Tech. degree,
          <br />
          including interdisciplinary programs in engineering education, in partnership with the École Centrale Group of Institutions of France.
        </p>
        <Link to="/" className="hero-btn" onClick={handleScrollToCourse}>
            Explore More
        </Link>
      </div>
    </header>
  );
};

// Course component
const Course = () => {
  return (
    <section className="course" id="course_call">
      <h1>Course We Offer</h1>
      <p>We are offer to four best courses for student by Mahindra University</p>

      <div className="row">
            <div class="course-col">
                <h3>School of Engineering</h3>
                <p>The School of Engineering, spanning various disciplines like civil, mechanical, electrical, and computer engineering, typically entails 8 semesters of rigorous study, integrating theory with hands-on projects.</p>
                <div className='flex flex-col gap-2'>
                  <Link to="/get-courses-engg">
                    <Button size="" variant="ghost" className="border border-black">Get Courses</Button>
                  </Link>
                  <Link to="/get-schedule-engg">
                    <Button size="" variant="ghost" className="border border-black">Get Schedule</Button>
                  </Link>
                </div>
            </div>

            <div class="course-col">
                <h3>School of Law</h3>
                <p>The School of Law offers comprehensive legal education, covering diverse fields such as criminal law, constitutional law, and corporate law. With typically six semesters of study.</p>
                <div className='flex flex-col gap-2'>
                  <Link to="/get-courses-law">
                    <Button size="" variant="ghost" className="border border-black">Get Courses</Button>
                  </Link>
                  <Link to="/get-schedule-law">
                    <Button size="" variant="ghost" className="border border-black">Get Schedule</Button>
                  </Link>
                </div>
            </div>

            <div class="course-col">
                <h3>School of Management</h3>
                <p>The School of Management provides a dynamic learning environment, offering courses in finance, marketing, operations, and strategy. Typically comprising eight semesters, it equips students with leadership and analytical skills.</p>
                <div className='flex flex-col gap-2'>
                  <Link to="/get-courses-mngt">
                    <Button size="" variant="ghost" className="border border-black">Get Courses</Button>
                  </Link>
                  <Link to="/get-schedule-mngt">
                    <Button size="" variant="ghost" className="border border-black">Get Schedule</Button>
                  </Link>
                </div>
            </div>

            <div class="course-col">
                <h3>School of Education</h3>
                <p>The School of Education prepares future educators with pedagogical expertise across various disciplines. Typically spanning six semesters, it focuses on teaching methodologies, curriculum design, and classroom management.</p>
                <div className='flex flex-col gap-2'>
                  <Link to="/get-courses-edu">
                      <Button size="" variant="ghost" className="border border-black">Get Courses</Button>
                  </Link>
                  <Link to="/get-schedule-edu">
                    <Button size="" variant="ghost" className="border border-black">Get Schedule</Button>
                  </Link>
                </div>
            </div>
      </div>
    </section>
  );
};

// Campus component
const Campus = () => {
  return (
    <section className="campus">
      <h1>Our Campus</h1>
      <div className="row">
        <div className="campus-col">
        <img src="./image/cm1.jfif" alt="Campus" />
          <div className="layer">
            <h3>Environment</h3>
          </div>
        </div>
        <div class="campus-col">
          <img src="./image/cm2.jfif" alt=""/>
          <div class="layer">
              <h3>Community</h3>
          </div>
        </div>

        <div class="campus-col">
            <img src="./image/cm3.jfif" alt=""/>
            <div class="layer">
                <h3>Education</h3>
            </div>
        </div>
        {/* Add remaining campus images */}
      </div>
    </section>
  );
};

// Facilities component
const Facilities = () => {
  return (
    <section className="facilities">
      <div className="facilities-heading">
        <h1>Our facilities</h1>
        <p>Facilities provide for Students by Mahindra University</p>
      </div>
      <div className="row">
        <div className="facilities-col">
          <img src="./image/canteen.png" alt="Canteen" />
          <h3>Canteen</h3>
          <p>
            The objective of the Canteen and meal service is to protect by reducing the risk of foodborne illness, with proper sanitary conditions.
          </p>
        </div>
        <div class="facilities-col">
            <img src="./image/auditorium.png" alt=""/>
            <h3>Auditorium</h3>
            <p>The college is having a huge indoor auditorium with a professionally-deployed acoustic system and a seating capacity of about 200 people.</p>
        </div>

        <div class="facilities-col">
            <img src="./image/hostel.png" alt=""/>
            <h3>Hostel</h3>
            <p>hostel consists of a separate mess, administrative office, warden quarter. In addition to well furnished rooms.</p>
          </div>
      </div>
    </section>
  );
};

// CallToAction component
const CallToAction = () => {
  return(
    <section className="ctn">
          <h1> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </h1>
    </section>
  ); 
};

// Footer component
const Footer = () => {
  return (
    <section className="footer">
      <h4>About Us</h4>
      <p>
        The Mahindra University provide one of the earliest form of technical studies, which has been vital in setting up the standard of brilliance.
      </p>
    </section>
  );
};

// App component
const App = () => {
  const courseRef = useRef(null);
  const campusRef = useRef(null);
  const facilitiesRef = useRef(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <Router>
      <div>
        <Routes>
          <Route
            path="/"
            element={
              <>
                <Header 
                  isMenuOpen={isMenuOpen}
                  setIsMenuOpen={setIsMenuOpen} 
                  handleScrollToCourse={() => courseRef.current.scrollIntoView({ behavior: 'smooth' })}
                  handleScrollToCampus={() => campusRef.current.scrollIntoView({ behavior: 'smooth' })}
                  handleScrollToFacilities={() => facilitiesRef.current.scrollIntoView({ behavior: 'smooth' })}  
                />
                <div ref={courseRef}>
                  <Course />
                </div>
                <div ref={campusRef}>
                  <Campus />
                </div>
                <div ref={facilitiesRef}>
                  <Facilities />
                </div>
                <CallToAction />
                <Footer />
              </>
            }
          />
          <Route path="/courses" element={<Course/>} />
          {/* School of Engineering */}
          <Route path='/get-courses-engg' element={<GetCoursesEngg/>}/>
          <Route path="/get-schedule-engg" element={<GetScheduleEngg />} />

          {/* School of Law */}
          <Route path='/get-courses-law' element={<GetCoursesLaw/>}/>
          <Route path="/get-schedule-law" element={<GetScheduleLaw />} />

          {/* School of Management */}
          <Route path='/get-courses-mngt' element={<GetCoursesMngt/>}/>
          <Route path="/get-schedule-mngt" element={<GetScheduleMngt />} />

          {/* School of Education */}
          <Route path='/get-courses-edu' element={<GetCoursesEdu/>}/>
          <Route path="/get-schedule-edu" element={<GetScheduleEdu />} />

          <Route path="/school-of-engineering" element={<SchoolOfEngineering />} />
          <Route path="/school-of-law" element={<SchoolOfLaw />} />
          <Route path="/school-of-management" element={<SchoolOfManagement />} />
          <Route path="/school-of-education" element={<SchoolOfEducation />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
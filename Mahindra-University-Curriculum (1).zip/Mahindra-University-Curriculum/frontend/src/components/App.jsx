import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [school, setSchool] = useState('');
  const [branch, setBranch] = useState('');
  const [year, setYear] = useState('');
  const [semester, setSemester] = useState('');
  const [courses, setCourses] = useState([]);

  const fetchCourses = async () => {
    try {
      const url = `http://localhost:5001/api/courses?school=${school}&branch=${branch}&year=${year}&semester=${semester}`;
      console.log('Fetching courses from:', url); // Log the URL
  
      const response = await axios.get(url);
      setCourses(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchCourses();
  };

  return (
    <div>
      <h1>Curriculum</h1>
      <form onSubmit={handleSubmit}>
        <select value={school} onChange={(e) => setSchool(e.target.value)}>
          <option value="">Select School</option>
          <option value="School of Engineering">School of Engineering</option>
          <option value="School of Law">School of Law</option>
          <option value="School Of Management">School Of Management</option>
          <option value="School of Education">School of Education</option>
        </select>
        {school === 'School of Engineering' && (
          <select value={branch} onChange={(e) => setBranch(e.target.value)}>
            <option value="">Select Branch</option>
            <option value="CSE">CSE</option>
            <option value="AI">AI</option>
            <option value="ECE">ECE</option>
            <option value="CM">CM</option>
            <option value="MT/NT">MT/NT</option>
          </select>
        )}
        <select value={year} onChange={(e) => setYear(e.target.value)}>
          <option value="">Select Year</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
        </select>
        <select value={semester} onChange={(e) => setSemester(e.target.value)}>
          <option value="">Select Semester</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
        </select>
        <button type="submit">Get Timetable</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>Name of the course</th>
            <th>Credits</th>
            <th>Professor</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course) => (
            <tr key={course._id}>
              <td>{course.name}</td>
              <td>{course.credits}</td>
              <td>{course.professor}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;

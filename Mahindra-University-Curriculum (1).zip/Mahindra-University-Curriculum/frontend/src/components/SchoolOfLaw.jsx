import React, { useState, useEffect } from "react";
import axios from "axios";

const SchoolOfLaw = () => {
  const [branch, setBranch] = useState("");
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [courses, setCourses] = useState([]);

  const fetchCourses = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/courses?school=School of Law&branch=${branch}&year=${year}&semester=${semester}`
      );
      setCourses(response.data);
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  };

  const handleGetTimetable = () => {
    fetchCourses();
  };

  return (
    <div>
      <h2>School of Law</h2>
      <div>
        <label htmlFor="branch">Branch:</label>
        <input
          type="text"
          id="branch"
          value={branch}
          onChange={(e) => setBranch(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="year">Year:</label>
        <input
          type="number"
          id="year"
          value={year}
          onChange={(e) => setYear(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="semester">Semester:</label>
        <input
          type="number"
          id="semester"
          value={semester}
          onChange={(e) => setSemester(e.target.value)}
        />
      </div>
      <button onClick={handleGetTimetable}>Get Timetable</button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Credits</th>
            <th>Professor</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course) => (
            <tr key={course._id}>
              <td>{course.name}</td>
              <td>{course.credits}</td>
              <td>{course.professor}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SchoolOfLaw;

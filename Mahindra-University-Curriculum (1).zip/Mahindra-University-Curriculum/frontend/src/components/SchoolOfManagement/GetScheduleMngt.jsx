import React, { useState, useEffect } from "react";
import axios from "axios";
import { Schedule } from "@syncfusion/ej2-react-schedule";
import Scheduler from "../Scheduler";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Toaster, toast } from "sonner";

const GetScheduleMngt = () => {
  const [branch, setBranch] = useState("");
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [courses, setCourses] = useState([]);

  const fetchCourses = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/courses?school=School of Management&branch=${branch}&year=${year}&semester=${semester}`
      );
      if (response.status === 200) {
        if (response.data.length === 0) {
          toast.error("No data found");
        } else {
          setCourses(response.data);
        }
      } else {
        console.error("Error fetching courses:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  };

  const handleGetTimetable = () => {
    fetchCourses();
  };

  const handleBranchChange = (value) => {
    setBranch(value);
  };

  const handleYearChange = (value) => {
    setYear(value);
  };

  const handleSemesterChange = (value) => {
    setSemester(value);
  };

  return (
    <div>
      <Toaster richColors position="top-right" />
      <h2 class="mt-4 font-extrabold text-3xl text-center text-gray-900 uppercase tracking-wide mb-4">
        School of Management
      </h2>

      <div>
        <div className="flex flex-col md:flex-row gap-3 items-center mt-4 mb-4">
          <div className="flex flex-row">
            <SelectGroup>
              <SelectLabel>Branch:</SelectLabel>
            </SelectGroup>
            <Select onValueChange={handleBranchChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Marketing Management">
                  Marketing Management
                </SelectItem>
                <SelectItem value="Finance Management">
                  Finance Management
                </SelectItem>
                <SelectItem value="Human Resource Management">
                  Human Resource Management
                </SelectItem>
                <SelectItem value="Operations Management">
                  Operations Management
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-row md:ml-3">
            <SelectGroup>
              <SelectLabel>Year:</SelectLabel>
            </SelectGroup>
            <Select onValueChange={handleYearChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1</SelectItem>
                <SelectItem value="2">2</SelectItem>
                <SelectItem value="3">3</SelectItem>
                <SelectItem value="4">4</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-row md:ml-3">
            <SelectGroup>
              <SelectLabel>Semester:</SelectLabel>
            </SelectGroup>
            <Select onValueChange={handleSemesterChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Semester" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1</SelectItem>
                <SelectItem value="2">2</SelectItem>
                <SelectItem value="3">3</SelectItem>
                <SelectItem value="4">4</SelectItem>
                <SelectItem value="5">5</SelectItem>
                <SelectItem value="6">6</SelectItem>
                <SelectItem value="7">7</SelectItem>
                <SelectItem value="8">8</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-row mt-4 md:mt-0">
            <div className="flex-grow"></div>
            <Button onClick={handleGetTimetable}>Get Schedule</Button>
          </div>
        </div>
      </div>
      <div className="mt-4 pt-2">
        <Label className="text-2xl text-gray-800 mb-2 ml-2 mt-4">
          Schedule:
        </Label>
      </div>
      <div className="mt-4">
        <Scheduler courses={courses} className="mt-4" />
      </div>
      {/* <Scheduler /> */}
    </div>
  );
};

export default GetScheduleMngt;

// import {
//   ScheduleComponent,
//   Inject,
//   Day,
//   Week,
//   WorkWeek,
//   Month,
//   Agenda,
//   ViewsDirective,
//   ViewDirective,
// } from "@syncfusion/ej2-react-schedule";
// import { useState } from "react";
// import axios from "axios";

// const Scheduler = () => {
//   const [scheduleData, setScheduleData] = useState([]);
//   const [selectedDate, setSelectedDate] = useState(new Date());
//   const [branch, setBranch] = useState("");
//   const [year, setYear] = useState("");
//   const [semester, setSemester] = useState("");
//   const [courses, setCourses] = useState([]);

//   const handleScheduleData = async () => {
//     // Call your API to fetch the schedule data for the given course, year, and semester
//     const response = await axios.get(
//       `http://localhost:9000/api/courses?school=School of Engineering&branch=${branch}&year=${year}&semester=${semester}`
//     );
//     setScheduleData(response.data);
//     console.log(response.data);
//   };

//   return (
//     <ScheduleComponent
//       id="schedule"
//       selectedDate={selectedDate}
//       currentView="Month"
//       //   selectedDate={new Date(2024, 0, 5)}
//       eventSettings={{ dataSource: scheduleData }}
//       height="550px"
//     >
//       <Inject services={[Day, Week, WorkWeek, Month, Agenda]} />
//     </ScheduleComponent>
//   );
// };

// export default Scheduler;

// import {
//   ScheduleComponent,
//   Inject,
//   Day,
//   Week,
//   WorkWeek,
//   Month,
//   Agenda,
//   ViewsDirective,
//   ViewDirective,
// } from "@syncfusion/ej2-react-schedule";
// import { useState } from "react";

// const Scheduler = ({ courses }) => {
//   const [selectedDate, setSelectedDate] = useState(new Date());

//   const formattedData = courses.reduce((acc, course) => {
//     const scheduledDays = [1, 2, 3, 4, 5]; // Monday to Friday
//     const startDate = new Date(2024, 0, 1); // Replace with your desired start date
//     const endDate = new Date(2024, 5, 30); // Replace with your desired end date (6 months from start date)

//     let currentTime = new Date(2024, 0, 1, 8, 0); // Start at 8:00 AM

//     for (
//       let date = startDate;
//       date <= endDate;
//       date.setDate(date.getDate() + 1)
//     ) {
//       const day = date.getDay();
//       if (scheduledDays.includes(day)) {
//         while (currentTime.getHours() < 16) {
//           // Stop at 4:00 PM
//           const endTime = new Date(currentTime.getTime() + 50 * 60000); // Add 50 minutes (class duration)

//           acc.push({
//             Id: `${
//               course._id
//             }_${date.toISOString()}_${currentTime.toISOString()}`,
//             Subject: course.name,
//             StartTime: new Date(
//               date.getFullYear(),
//               date.getMonth(),
//               date.getDate(),
//               currentTime.getHours(),
//               currentTime.getMinutes()
//             ),
//             EndTime: new Date(
//               date.getFullYear(),
//               date.getMonth(),
//               date.getDate(),
//               endTime.getHours(),
//               endTime.getMinutes()
//             ),
//           });

//           currentTime = new Date(endTime.getTime() + 10 * 60000); // Add 10 minutes (break duration)
//         }

//         currentTime = new Date(2024, 0, 1, 8, 0); // Reset currentTime to 8:00 AM for the next day
//       }
//     }

//     return acc;
//   }, []);

//   return (
//     <ScheduleComponent
//       id="schedule"
//       selectedDate={selectedDate}
//       currentView="Month"
//       eventSettings={{ dataSource: formattedData }}
//       height="550px"
//     >
//       <Inject services={[Day, Week, WorkWeek, Month, Agenda]} />
//     </ScheduleComponent>
//   );
// };

// export default Scheduler;
// import {
//   ScheduleComponent,
//   Inject,
//   Day,
//   Week,
//   WorkWeek,
//   Month,
//   Agenda,
//   ViewsDirective,
//   ViewDirective,
// } from "@syncfusion/ej2-react-schedule";
// import { useState } from "react";

// const Scheduler = ({ courses }) => {
//   const [selectedDate, setSelectedDate] = useState(new Date());

//   const formattedData = courses.reduce((acc, course, index) => {
//     const scheduledDays = [1, 2, 3, 4, 5]; // Monday to Friday
//     const startDate = new Date(2024, 0, 1); // Replace with your desired start date
//     const endDate = new Date(2024, 5, 30); // Replace with your desired end date (6 months from start date)

//     for (
//       let date = startDate;
//       date <= endDate;
//       date.setDate(date.getDate() + 1)
//     ) {
//       const day = date.getDay();
//       if (scheduledDays.includes(day)) {
//         const startTime = new Date(
//           date.getFullYear(),
//           date.getMonth(),
//           date.getDate(),
//           8 + index,
//           0
//         ); // Calculate start time based on index
//         const endTime = new Date(startTime.getTime() + 50 * 60000); // Add 50 minutes (class duration)

//         acc.push({
//           Id: `${course._id}_${date.toISOString()}_${startTime.toISOString()}`,
//           Subject: course.name,
//           StartTime: startTime,
//           EndTime: endTime,
//         });
//       }
//     }

//     return acc;
//   }, []);

//   return (
//     <ScheduleComponent
//       id="schedule"
//       selectedDate={selectedDate}
//       currentView="Month"
//       eventSettings={{ dataSource: formattedData }}
//       height="550px"
//     >
//       <Inject services={[Day, Week, WorkWeek, Month, Agenda]} />
//     </ScheduleComponent>
//   );
// };

// export default Scheduler;

import {
  ScheduleComponent,
  Inject,
  Day,
  Week,
  WorkWeek,
  Month,
  Agenda,
  ViewsDirective,
  ViewDirective,
} from "@syncfusion/ej2-react-schedule";
import { useState } from "react";
import "./Scheduler.css";

const Scheduler = ({ courses }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());

  const formattedData = courses.reduce((acc, course, index) => {
    const scheduledDays = [1, 2, 3, 4, 5]; // Monday to Friday
    const startDate = new Date(2024, 0, 1); // Replace with your desired start date
    const endDate = new Date(2024, 5, 30); // Replace with your desired end date (6 months from start date)

    let currentDay = 1; // Start with Monday
    const noClassesDates = new Set(); // Set to store dates with "No Classes"

    for (
      let date = startDate;
      date <= endDate;
      date.setDate(date.getDate() + 1)
    ) {
      const day = date.getDay();
      if (scheduledDays.includes(day)) {
        const startTime = new Date(
          date.getFullYear(),
          date.getMonth(),
          date.getDate(),
          8 + ((index + currentDay - 1) % courses.length),
          0
        ); // Calculate start time based on index and currentDay
        const endTime = new Date(startTime.getTime() + 50 * 60000); // Add 50 minutes (class duration)

        acc.push({
          Id: `${course._id}_${date.toISOString()}_${startTime.toISOString()}`,
          Subject: course.name,
          StartTime: startTime,
          EndTime: endTime,
          Background: `#${Math.floor(Math.random() * 0x1000000)
            .toString(16)
            .padStart(6, "0")}`, // Generate a random color in HTML/CSS format
        });

        currentDay = (currentDay % 5) + 1; // Update currentDay (1 for Monday, 2 for Tuesday, ..., 5 for Friday)
      } else if (
        (day === 0 || day === 6) &&
        !noClassesDates.has(date.toDateString())
      ) {
        // If it's Saturday (6) or Sunday (0), and "No Classes" event hasn't been added for this date
        noClassesDates.add(date.toDateString());
        acc.push({
          Id: `no-classes-${date.toISOString()}`,
          Subject: "No Classes",
          StartTime: new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            0,
            0
          ),
          EndTime: new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            23,
            59
          ),
          Background: "#e0e0e0", // Light gray color for "No Classes" events
          IsAllDay: true, // Set IsAllDay to true to remove time display
        });
      }
    }

    return acc;
  }, []);

  const eventRendered = (args) => {
    args.data.backgroundColor = args.data.Background;
  };

  return (
    <ScheduleComponent
      id="schedule"
      selectedDate={selectedDate}
      currentView="Month"
      eventSettings={{ dataSource: formattedData }}
      height="550px"
      eventRendered={eventRendered}
    >
      <Inject services={[Day, Week, WorkWeek, Month, Agenda]} />
    </ScheduleComponent>
  );
};

export default Scheduler;
